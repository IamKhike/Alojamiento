﻿using AlojamientoProyecto.Data;
using AlojamientoProyecto.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BCrypt.Net;

namespace AlojamientoProyecto.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly AppDbContext _context;

        public UserController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost("register")]
        public async Task<ActionResult> Register([FromBody] RegistroRequest usuario)
        {
            if (await _context.Usuarios.AnyAsync(u => u.email == usuario.email))
            {
                return BadRequest("El correo ya está registrado.");
            }

            var nuevoUsuario = new Usuario
            {
                nombre = usuario.nombre,
                email = usuario.email,
                password_hash = HashPassword(usuario.password)
            };

            _context.Usuarios.Add(nuevoUsuario);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Usuario registrado correctamente." });
        }

        
        [HttpPost("login")]
        public async Task<ActionResult> Login([FromBody] LoginRequest request)
        {
            var usuario = await _context.Usuarios.FirstOrDefaultAsync(u => u.email == request.email);

            if (usuario == null || !VerifyPassword(request.password, usuario.password_hash))
            {
                return Unauthorized("Correo o contraseña incorrectos.");
            }

            
            return Ok(new { userId = usuario.id, message = "Inicio de sesión exitoso" });
        }

        
        [HttpGet("validate/{id}")]
        public async Task<ActionResult> ValidateSession(int id)
        {
            var usuario = await _context.Usuarios.FindAsync(id);

            if (usuario == null)
            {
                return Unauthorized("Usuario no encontrado.");
            }

            return Ok(new { userId = usuario.id, usuario = usuario.nombre });
        }

        private static string HashPassword(string password)
        {
            return BCrypt.Net.BCrypt.HashPassword(password);
        }

        private static bool VerifyPassword(string password, string hashedPassword)
        {
            return BCrypt.Net.BCrypt.Verify(password, hashedPassword);
        }
    }
}
