﻿using AlojamientoProyecto.Data;
using AlojamientoProyecto.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text;
using BCrypt.Net;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;


namespace AlojamientoProyecto.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly AppDbContext _context;

        public UserController(AppDbContext context)
        {
            _context = context;
        }


        [HttpPost("register")]

        public async Task<ActionResult> Register([FromBody] RegistroRequest usuario)
        {
            if (await _context.Usuarios.AnyAsync(u => u.email == usuario.email))
            {
                return BadRequest("El correo ya está registrado.");
            }

            var nuevoUsuario = new Usuario
            {
                nombre = usuario.nombre,
                email = usuario.email,
                password_hash = HashPassword(usuario.password)
            };

            _context.Usuarios.Add(nuevoUsuario);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Usuario registrado correctamente." });
        }





        [HttpPost("login")]
        public async Task<ActionResult> Login([FromBody] LoginRequest request)
        {
            var usuario = await _context.Usuarios.FirstOrDefaultAsync(u => u.email == request.email);

            if (usuario == null || !VerifyPassword(request.password, usuario.password_hash))
            {
                return Unauthorized("Correo o contraseña incorrectos.");
            }

            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes("esta-es-una-clave-super-segura-y-larga");


            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
            new Claim("id", usuario.id.ToString()),
            new Claim("email", usuario.email)
        }),
                Expires = DateTime.UtcNow.AddHours(2),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            var jwtToken = tokenHandler.WriteToken(token);

            return Ok(new
            {
                token = jwtToken,
                nombre = usuario.nombre
            });
        }


        [HttpGet("validate")]
        [Authorize]
        public ActionResult ValidateSession()
        {
            var userId = User.Claims.FirstOrDefault(c => c.Type == "id")?.Value;
            var email = User.Claims.FirstOrDefault(c => c.Type == "email")?.Value;

            return Ok(new { userId, email });
        }



        private static string HashPassword(string password)
        {
            return BCrypt.Net.BCrypt.HashPassword(password);
        }

        private static bool VerifyPassword(string password, string hashedPassword)
        {
            return BCrypt.Net.BCrypt.Verify(password, hashedPassword);
        }
    }
}
