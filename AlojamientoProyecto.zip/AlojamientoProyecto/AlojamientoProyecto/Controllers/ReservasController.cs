﻿using AlojamientoProyecto.Data;
using AlojamientoProyecto.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AlojamientoProyecto.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ReservasController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ReservasController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost("CrearReservas")]
        public async Task<ActionResult> CrearReserva([FromBody] Reserva reserva)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            reserva.Alojamiento = null;
            reserva.fecha_inicio = reserva.fecha_inicio.ToUniversalTime();
            reserva.fecha_fin = reserva.fecha_fin.ToUniversalTime();

            try
            {
                _context.Reservas.Add(reserva);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(GetReservasPorUsuario), new { usuarioId = reserva.usuario_id });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    message = "Hubo un problema al guardar la reserva.",
                    error = ex.InnerException?.Message ?? ex.Message
                });
            }
        }





        
        [HttpGet("ObtenerReservasPorUsuario/{usuarioId}")]
        public async Task<IActionResult> GetReservasPorUsuario(int usuarioId)
        {
            var reservas = await _context.Reservas
                .Where(r => r.usuario_id == usuarioId)
                .Include(r => r.Alojamiento) 
                .Select(r => new
                {
                    r.id,
                    r.fecha_inicio,
                    r.fecha_fin,
                    r.precio,
                    r.numero_huespedes,
                    Alojamiento = new
                    {
                        r.Alojamiento.nombre,
                        r.Alojamiento.ubicacion,
                        r.Alojamiento.url_imagen
                    }
                })
                .ToListAsync();

            if (!reservas.Any())
            {
                return NotFound(new { message = "No se encontraron reservas para este usuario." });
            }

            return Ok(reservas);
        }


        
        [HttpDelete("{id}/Usuario/{usuarioId}")]
        public async Task<IActionResult> DeleteReserva(int id, int usuarioId)
        {
           
            var reserva = await _context.Reservas
                .FirstOrDefaultAsync(r => r.id == id && r.usuario_id == usuarioId);

            if (reserva == null)
            {
                return NotFound(new { message = "Reserva no encontrada o no pertenece a este usuario." });
            }
            
            
            _context.Reservas.Remove(reserva);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Reserva eliminada correctamente." });
        }


        
        [HttpPut("{id}/Usuario/{usuarioId}")]
        public async Task<IActionResult> ActualizarReserva(int id, int usuarioId, [FromBody] Reserva reservaActualizada)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var reserva = await _context.Reservas
                .FirstOrDefaultAsync(r => r.id == id && r.usuario_id == usuarioId);

            if (reserva == null)
            {
                return NotFound(new { message = "Reserva no encontrada o no pertenece a este usuario." });
            }

            try
            {
                
                reserva.alojamiento_id = reservaActualizada.alojamiento_id;
                reserva.fecha_inicio = reservaActualizada.fecha_inicio.ToUniversalTime();
                reserva.fecha_fin = reservaActualizada.fecha_fin.ToUniversalTime();
                reserva.precio = reservaActualizada.precio;
                reserva.numero_huespedes = reservaActualizada.numero_huespedes;

                _context.Reservas.Update(reserva);
                await _context.SaveChangesAsync();

                return Ok(new { message = "Reserva actualizada correctamente." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    message = "Hubo un problema al actualizar la reserva.",
                    error = ex.InnerException?.Message ?? ex.Message
                });
            }
        }


        [HttpGet("FechasOcupadas/{alojamientoId}")]
        public async Task<IActionResult> GetFechasOcupadas(int alojamientoId)
        {
            
            var reservas = await _context.Reservas
                .Where(r => r.alojamiento_id == alojamientoId)
                .ToListAsync();

            
            var fechasOcupadas = reservas
                .SelectMany(r => Enumerable.Range(0, (int)(r.fecha_fin - r.fecha_inicio).TotalDays + 1)
                                           .Select(offset => r.fecha_inicio.AddDays(offset).ToString("yyyy-MM-dd")))
                .ToList();

            return Ok(fechasOcupadas);
        }




    }
}
