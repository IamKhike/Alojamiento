using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using AlojamientoProyecto.Data;
using AlojamientoProyecto.Models;
using System.Text;

namespace AlojamientoProyecto.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AlojamientosController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AlojamientosController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("destacados")]
        public async Task<ActionResult<IEnumerable<Alojamiento>>> GetDestacados()
        {
            return await _context.Alojamientos.Where(a => a.destacado).ToListAsync();
        }

        [HttpGet]
        public async Task<ActionResult<List<Alojamiento>>> GetAlojamientos()
        {
           
            return await _context.Alojamientos.ToListAsync();
        }


        
    }
        
}

