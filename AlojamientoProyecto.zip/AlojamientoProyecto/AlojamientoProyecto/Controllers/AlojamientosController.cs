using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using AlojamientoProyecto.Data;
using AlojamientoProyecto.Models;
using System.Text;

namespace AlojamientoProyecto.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AlojamientosController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AlojamientosController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("destacados")]
        public async Task<ActionResult<IEnumerable<Alojamiento>>> GetDestacados()
        {
            return await _context.Alojamientos.Where(a => a.destacado).ToListAsync();
        }

        [HttpGet]
        public async Task<ActionResult<List<Alojamiento>>> GetAlojamientos()
        {
           
            return await _context.Alojamientos.ToListAsync();
        }


   
    





         [HttpPost("register")]

        public async Task<ActionResult> Register([FromBody] RegistroRequest usuario)
        {
            if (await _context.Usuarios.AnyAsync(u => u.email == usuario.email))
            {
                return BadRequest("El correo ya est� registrado.");
            }

            var nuevoUsuario = new Usuario
            {
                nombre = usuario.nombre,
                email = usuario.email,
                password_hash = HashPassword(usuario.password)
            };

            _context.Usuarios.Add(nuevoUsuario);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Usuario registrado correctamente." });
        }




        
        [HttpPost("login")]  
        public async Task<ActionResult> Login([FromBody] LoginRequest request)  
        {
            var usuario = await _context.Usuarios.FirstOrDefaultAsync(u => u.email == request.email);

            if (usuario == null || !VerifyPassword(request.password, usuario.password_hash))
            {
                return Unauthorized("Correo o contrase�a incorrectos.");
            }

            string token = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{usuario.id}:{usuario.email}"));

            return Ok(new { token });
        }

   
        [HttpGet("validate")]
        public ActionResult ValidateSession(string token)
        {
            if (string.IsNullOrEmpty(token))
            {
                return Unauthorized("Token no proporcionado.");
            }

           
            string decodedToken = Encoding.UTF8.GetString(Convert.FromBase64String(token));
            string[] parts = decodedToken.Split(':');

            if (parts.Length != 2)
            {
                return Unauthorized("Token inv�lido.");
            }

            int userId = int.Parse(parts[0]);
            string email = parts[1];

            return Ok(new { userId, email });
        }

        
        private static string HashPassword(string password)
        {
            using var sha256 = SHA256.Create();
            byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
            return Convert.ToBase64String(bytes);
        }

        // Helper: Verify Password
        private static bool VerifyPassword(string password, string hashedPassword)
        {
            return HashPassword(password) == hashedPassword;
        }







        // Crear una nueva reserva
        [HttpPost("CrearReservas")]
        public async Task<ActionResult<Reserva>> CrearReserva(Reserva reserva)
        {
            if (reserva == null)
            {
                return BadRequest("Reserva no v�lida");
            }

            // Agregar la reserva a la base de datos
            _context.Reservas.Add(reserva);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetReserva), new { id = reserva.id }, reserva);
        }

        // Obtener todas las reservas
        [HttpGet("ObtenerReservas")]
        public async Task<ActionResult<IEnumerable<Reserva>>> GetReservas()
        {
            return await _context.Reservas.ToListAsync();
        }



        // Obtener una reserva por ID
        [HttpGet("{id}")]
        public async Task<ActionResult<Reserva>> GetReserva(int id)
        {
            var reserva = await _context.Reservas.FindAsync(id);

            if (reserva == null)
            {
                return NotFound();
            }

            return reserva;
        }

        // Eliminar una reserva por ID
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteReserva(int id)
        {
            var reserva = await _context.Reservas.FindAsync(id);

            if (reserva == null)
            {
                return NotFound();
            }

            _context.Reservas.Remove(reserva);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
        
}

