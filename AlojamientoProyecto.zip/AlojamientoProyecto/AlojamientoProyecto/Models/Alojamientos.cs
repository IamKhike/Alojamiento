using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace AlojamientoProyecto.Models
{
    [Table("alojamientos")]
    public class Alojamiento
    {
        public int id { get; set; }
        public string nombre { get; set; }
        public string ubicacion { get; set; }
        public string tipo_alojamiento { get; set; }
        public decimal precio { get; set; }
        public string descripcion_corta { get; set; }
        public bool destacado { get; set; }
        public string provincia { get; set; }
        public string url_imagen { get; set; }
        public int capacidad_huespedes { get; set; }
    }

    [Table("usuarios")]
    public class Usuario
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id { get; set; }
        [Required]
        public string nombre { get; set; }
        [Required, EmailAddress]
        public string email { get; set; }
        [Required]
        [JsonIgnore] // Oculta la contrase�a en las respuestas de la API
        public string password_hash { get; set; }
    }

    public class RegistroRequest
    {
        [Required]
        public string nombre { get; set; }

        [Required]
        [EmailAddress]
        public string email { get; set; }

        [Required]
        public string password { get; set; }
    }

    public class LoginRequest
    {
        [Required]
        [EmailAddress]
        public string email { get; set; }

        [Required]
        public string password { get; set; }
    }

    [Table("reservas")]
    public class Reserva
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id { get; set; }
        public int alojamiento_id { get; set; }
        public int usuario_id { get; set; }
        public DateTime fecha_inicio { get; set; }
        public DateTime fecha_fin { get; set; }
    }


}
