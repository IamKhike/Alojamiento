﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace AlojamientoProyecto.Models
{
    [Table("reservas")]
    public class Reserva
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]

        public int id { get; set; }

        [Required(ErrorMessage = "El ID del alojamiento es obligatorio")]
        public int alojamiento_id { get; set; }

        [Required(ErrorMessage = "El ID del usuario es obligatorio")]
        public int usuario_id { get; set; }

        [Required(ErrorMessage = "La fecha de inicio es obligatoria")]
        [DataType(DataType.Date)]
        public DateTime fecha_inicio { get; set; }

        [Required(ErrorMessage = "La fecha de fin es obligatoria")]
        [DataType(DataType.Date)]
        public DateTime fecha_fin { get; set; }

        [Required(ErrorMessage = "El precio total de la reserva es obligatorio")]
        [Range(0.01, double.MaxValue, ErrorMessage = "El precio debe ser mayor a 0")]
        public decimal precio { get; set; }

        [Required(ErrorMessage = "El número de huéspedes es obligatorio")]
        [Range(1, int.MaxValue, ErrorMessage = "Debe haber al menos 1 huésped")]
        public int numero_huespedes { get; set; } 



        public Alojamiento? Alojamiento { get; set; }
    }

}

