using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace AlojamientoProyecto.Models
{
    [Table("alojamientos")]
    public class Alojamiento
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id { get; set; }
        public string nombre { get; set; }
        public string ubicacion { get; set; }
        public string tipo_alojamiento { get; set; }
        public decimal precio { get; set; }
        public string descripcion_corta { get; set; }
        public bool destacado { get; set; }
        public string provincia { get; set; }
        public string url_imagen { get; set; }
        public int capacidad_huespedes { get; set; }
    }


}
